<?php
header('Location: forgot_password.php');
exit();
